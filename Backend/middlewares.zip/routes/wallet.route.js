import express from "express";
import { getWallet, addFunds, getTransactions, getTomorrowSummary, getUserSubscriptions, getAllUsers, createUser, overrideCredit, updateUserStatus, assignDeliveryZones, updateUserDislikes, adjustUserWallet, getUserWalletTransactions } from "../controllers/wallet.controller.js";
import { requireAuth, requireRole } from "../middlewares/auth.middleware.js";
import { upload } from "../middlewares/multer.js";

const router = express.Router();

// Wallet (user)
router.get("/wallet", requireAuth, getWallet);
router.post("/add-funds", requireAuth, addFunds);
router.get("/wallet/transactions", requireAuth, getTransactions);

// Admin
router.get("/admin/tomorrow-summary", requireAuth, requireRole(["admin"]), getTomorrowSummary);
router.get("/admin/users", requireAuth, requireRole(["admin"]), getAllUsers);
router.post("/admin/users", requireAuth, requireRole(["admin"]), createUser);
router.get("/admin/user/:id/all-subscriptions", requireAuth, requireRole(["admin"]), getUserSubscriptions);
router.patch("/admin/credit/:id/override", requireAuth, requireRole(["admin"]), overrideCredit);
router.patch("/admin/users/:id/status", requireAuth, requireRole(["admin"]), updateUserStatus);
router.patch("/admin/users/:id/delivery-zones", requireAuth, requireRole(["admin"]), assignDeliveryZones);
router.put("/admin/users/:id/dislikes", requireAuth, requireRole(["admin"]), updateUserDislikes);

// New Admin Wallet Routes
router.post("/admin/users/:id/wallet/adjust", requireAuth, requireRole(["admin"]), upload.single("photo"), adjustUserWallet);
router.get("/admin/users/:id/wallet/transactions", requireAuth, requireRole(["admin"]), getUserWalletTransactions);

export default router;
